# qb-template
QBCore Template Script
